/* ISC license. */

#ifndef S6NET_H
#define S6NET_H

#include <s6-networking/ident.h>

#endif
